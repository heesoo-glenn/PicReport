package application;

import java.io.File;
import java.util.List;

public class Work {
	private File inputExcel;
	private File pictureDir;
	private List<File> pictures;
	
	
	public File getInputExcel() {
		return inputExcel;
	}
	public void setInputExcel(File inputExcel) {
		this.inputExcel = inputExcel;
	}
	public File getPictureDir() {
		return pictureDir;
	}
	public void setPictureDir(File pictureDir) {
		this.pictureDir = pictureDir;
	}
	public List<File> getPictures() {
		return pictures;
	}
	public void setPictures(List<File> pictures) {
		this.pictures = pictures;
	}
	
	
}
